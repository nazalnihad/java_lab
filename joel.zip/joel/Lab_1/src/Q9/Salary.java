/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Q9;

/**
 *
 * @author nazal
 */
//Create an interface Salary with a
//function salary calculation.
public interface Salary {
    void CalcSalary();
}
