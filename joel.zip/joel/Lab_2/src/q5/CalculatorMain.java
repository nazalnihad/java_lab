/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q5;

/**
 *
 * @author nazal
 */
public class CalculatorMain {
    public static void main(String[] args){
    Calculator calculator = new Calculator();
//    calculator();
    }
}
