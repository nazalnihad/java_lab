/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q4;

/**
 *
 * @author nazal
 */
public class Q4_Main {
    public static void main(String[] args){
        EmployeeList obj = new EmployeeList(2);
        obj.getEmployees();
        obj.sortList();
        obj.displaySorted();
    }
}
